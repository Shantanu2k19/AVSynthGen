def CheckGPTConnection():
    print("checking")
    return {"statusCode": 200, "body": "Hello, World!"} 
