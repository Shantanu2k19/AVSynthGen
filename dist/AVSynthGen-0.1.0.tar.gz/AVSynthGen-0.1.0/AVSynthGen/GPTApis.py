def CheckGPTConnection():
    print("checking")
    return 
